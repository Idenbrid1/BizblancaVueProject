<template>
    <div>
        <WebsiteNavbar />
        <CompanyNavbar />
        <div class="faq-title">
            <h1 class="faq-title">FAQS</h1>
            <p>Here are some of the frequently ask questions.</p>
        </div>

        <div class="pacakges-plan-container container p-md-2 p-0">
            <!-- Nav pills -->
            <ul class="nav nav-pills faq-tabs-list" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="pill" href="#general-tab">
                        <i class="fas fa-users"></i>
                        <span>General</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="pill" href="#payment-tab">
                        <i class="fas fa-users"></i>
                        <span>Payment</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="pill" href="#refund-tab">
                        <i class="fas fa-users"></i>
                        <span>Refund</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="pill" href="#products-services">
                        <i class="fas fa-users"></i>
                        <span>Products & Services</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="pill" href="#registration-tab">
                        <i class="fas fa-users"></i>
                        <span>Registration Issue</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="pill" href="#technical-tab">
                        <i class="fas fa-users"></i>
                        <span>Technical Issue</span>
                    </a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div id="general-tab" class="container tab-pane active"><br>
                    <section class="need-help-section">
                        <h1 class="need-help-title">Need Help?</h1>
                        <div class="help-queries-wrap">
                            <div class="help-queries">
                                <h4>Q. What is BizBlanca?</h4>
                                <p>
                                    BizBlanca is a job-search portal for IT professionals that connects job seekers with
                                    reputable IT companies across the country and helps them discover jobs that
                                    perfectly fit their needs.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. How Is BizBlanca Different From Others?</h4>
                                <p>
                                    Unlike other job searching platforms, BizBlanca supports the IT sector only. It's a
                                    dream-come-true platform for applicants who enjoy coding and managing businesses
                                    using advanced IT technologies.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. Can I Get An IT Job In This Pandemic?</h4>
                                <p>
                                    Bravo! You've come to the right place to look for IT jobs from the comfort of your
                                    own home. You don’t need to roam here & there physically to find a job now. Simply
                                    create an account on our website and search for your ideal job.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. I Am Tired Of Looking For IT jobs. Can I Get One Here?</h4>
                                <p>
                                    You certainly can! Let's make it modest to begin your IT career. We've got you
                                    covered with our IT recruitment expertise and are always ready to help you out with
                                    the finest available services. Just ping us!
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. How Can I Get A Job?</h4>
                                <p>
                                    Bizblanca encourages and supports people who are keen to work in the IT field. All
                                    you have to do is create & submit a well-optimized CV and wait for the recruiter to
                                    contact you after applying.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div id="payment-tab" class="container tab-pane fade"><br>
                    <section class="need-help-section">
                        <h1 class="need-help-title">Need Help?</h1>
                        <div class="help-queries-wrap">
                            <div class="help-queries">
                                <h4>Q. What payment methods do you accept?</h4>
                                <p>
                                    You can purchase on our website using a debit or credit card. We additionally offer
                                    support for Paypal, Amazon Pay, Apple Pay, and Google Play. You can choose these
                                    payment methods at checkout.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. Which currency will I be charged in?</h4>
                                <p>
                                    We currently only support charging our customers in their local currency, PKR.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. When is my credit card charged?</h4>
                                <p>
                                    Just before statements are mailed out, credit cards are charged. The charge's
                                    outcomes are immediately contained in the statement.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. What happens if I am unable to pay my bill by the due date?</h4>
                                <p>
                                    Accounts that are overdue for payment may have their services suspended at any time
                                    and without warning. The longer you've been late, the more probable this is to
                                    happen.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div id="refund-tab" class="container tab-pane fade"><br>
                    <section class="need-help-section">
                        <h1 class="need-help-title">Need Help?</h1>
                        <div class="help-queries-wrap">
                            <div class="help-queries">
                                <h4>Q. If my credit card is lost or stolen, what should I do?</h4>
                                <p>
                                    Not only should you notify your bank, but you should also notify us by withdrawing
                                    or altering the card details in the Account Control Center.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. What should I do if my credit card has been charged incorrectly?</h4>
                                <p>
                                    We'll gladly post refunds and modifications to the cards that we've processed.
                                    Before arguing the charges with your bank, it is preferable for everyone if you
                                    contact us and enable us to make the necessary adjustments.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. How soon do I have to provide a refund request after making a payment?</h4>
                                <p>
                                    Payments done through BizBlanca are refundable. You will have to request within 3-4
                                    working days to get your payment back.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. How long does it take to receive a refund?</h4>
                                <p>
                                    Refunds can take 9-14 business days to complete. Be patient, and wait for the right
                                    time to come.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. Is there any charge for giving refunds?</h4>
                                <p>
                                    No. refunding process is free of cost and you can do it anytime. But refunding is
                                    not an option for accepting security deposits or pre-authorized expenses. So you
                                    must verify and provide a valid reason for refunds.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div id="products-services" class="container tab-pane fade"><br>
                    <section class="need-help-section">
                        <h1 class="need-help-title">Need Help?</h1>
                        <div class="help-queries-wrap">
                            <div class="help-queries">
                                <h4>Q. Can I post for several jobs at the same time?</h4>
                                <p>
                                    By subscribing to our pricing plans, you can avail of services of posting multiple
                                    jobs at a time. The greater plan you choose, the more job posts you can do.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. Can I apply multiple times for a job?</h4>
                                <p>
                                    Yes, there are no limitations to applying for a job. If you are not short-listed for
                                    an interview, you can apply for that job again too.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. What kind of service response can I expect?</h4>
                                <p>
                                    Our support team is always here for your help. We typically reply within 24 hours
                                    and always give a satisfying response.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div id="registration-tab" class="container tab-pane fade"><br>
                    <section class="need-help-section">
                        <h1 class="need-help-title">Need Help?</h1>
                        <div class="help-queries-wrap">
                            <div class="help-queries">
                                <h4>Q. I didn’t get an email. What should I do?</h4>
                                <p>
                                    If you did not receive the confirmation or support email from us, you should check
                                    your junk or spam folder.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div id="technical-tab" class="container tab-pane fade"><br>
                    <section class="need-help-section">
                        <h1 class="need-help-title">Need Help?</h1>
                        <div class="help-queries-wrap">
                            <div class="help-queries">
                                <h4>Q. How To Succeed An IT Interview?</h4>
                                <p>
                                    Getting a job interview is an excellent beginning step to your IT career, but
                                    remember that it's just "half the fight. To succeed in an interview and get the job,
                                    you need to:
                                    <br /> Make Time For Practice
                                    <br /> Get Well Dressed.
                                    <br /> Thoroughly Research About The Company
                                    <br /> Be Authentic & Fully Confident
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. What IT Jobs Do You Provide?</h4>
                                <p>
                                    Support Specialist, Computer Programmer, Web Developer, IT Technician, UI/UX
                                    Designer, Database Administrator, and many other IT jobs are available on our site.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                            <div class="help-queries">
                                <h4>Q. There are already so many candidates. How can I stand out for the job?</h4>
                                <p>
                                    Focus on your strength and how to convey them. Build a personal brand, tailor your
                                    application materials to each position you apply to, and optimize organic keywords
                                    for your application materials.
                                </p>
                                <div>
                                    <a class="read-more-descrp" href="">Read More &nbsp;<i
                                            class="fas fa-angle-down"></i></a>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import WebsiteNavbar from '../website/partials/navbar.vue';

    export default {
        data() {
            return {

            }
        },
        mounted() {},
        created() {},
        components: {
            WebsiteNavbar,
        },
        methods: {

        },
    };

</script>
