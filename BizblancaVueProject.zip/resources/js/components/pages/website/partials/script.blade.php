 <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- <script src="{{asset('website')}}/assets/js/jquery/jquery.min.js"></script> -->
   <script src="{{asset('website')}}/assets/jquery-3.5.1.min.js"></script>

    <script src="{{asset('website')}}/assets/js/bootstrap/popper.min.js"></script>
    <script src="{{asset('website')}}/assets/js/bootstrap/bootstrap.min.js"></script>
    <script src="{{asset('website')}}/assets/js/swiper/swiper-bundle.min.js"></script>
    <script src="{{asset('website')}}/assets/js/main.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.6/cropper.js"></script>
    <script type="text/javascript"  src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="{{ asset('js/app.js') }}"></script>

@yield('other-scripts')