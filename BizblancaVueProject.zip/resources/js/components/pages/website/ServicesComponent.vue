<template>
    <div>
        <WebsiteNavbar />
        <CompanyNavbar />
        <h1 class="pricing-plan-title">Services</h1>
        <div class="pacakges-plan-container container">
            <div class="get-free-trial">
                <h2>Services We Offer To Companies</h2>
                <p>
                    At BizBlanca, companies secure opportunities to get connected with loyal & committed candidates that
                    perfectly fit their requirements. We offer a wide range of services to the companies which they can
                    avail after subscribing to our package.
                </p>
            </div>
            <div class="list-services">
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image">
                                <img src="/website/assets/images/Icon-awesome-question-circle.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">Web Developers</h3>
                            <p class="list__card-description body--sm">
                                A web developer knows HTML, CSS, JavaScript, and PHP. He is an expert in troubleshooting
                                website problems and also monitors website traffic. We connect you with highly-skilled
                                and expert web developers that create fast-loading and user-friendly sites.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group-1360.png"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">App Developers</h3>
                            <p class="list__card-description body--sm">
                                An application developer is typically responsible for coding, designing, and managing
                                the application. He’ll also make sure that the app runs smoothly. If you require
                                employees who can develop and create mobile apps, we will find them for you.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group1361.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">
                                AI Developer
                            </h3>
                            <p class="list__card-description body--sm">
                                AI developers help to answer complex business concerns with AI-developed software. He
                                designs a streamlined architecture of data management & transformation. For companies
                                that require to automate their business procedures, we connect them with proficient AI
                                Developers.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group1361.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">
                                IT Infrastructure
                            </h3>
                            <p class="list__card-description body--sm">
                                IT infrastructure engineers are in charge of the security of computer systems and data
                                exchanges across applications. If you want to manage the security of computer systems
                                and inter-application information transfers within a business, we help you hire an IT
                                Infrastructure Engineer.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group1361.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">
                                Digital Marketer
                            </h3>
                            <p class="list__card-description body--sm">
                                A Digital Marketer is responsible to ensure that the audience finds your website easily,
                                as well as driving more organic traffic. To grow and advertise your business, we help
                                you in recruiting Digital Marketers and SEO Experts that fit your requirements.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group1361.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">
                                ECommerce
                            </h3>
                            <p class="list__card-description body--sm">
                                Ecommerce developers are crucial in ensuring that potential clients can explore your
                                eCommerce site with ease and find out what products you sell or purchase. If your
                                company wants to sell products online, we connect you with a skilled and dedicated
                                ECommerce Developer.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group1361.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">
                                Data Science Expert
                            </h3>
                            <p class="list__card-description body--sm">
                                Data scientists use their experience in a range of data niches to support organizations
                                in interpreting and managing data and solving complex concerns. To keep your business
                                data & information in a secured and backup environment, we provide applications of Data
                                Science Experts.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group1361.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">
                                CMS Developer
                            </h3>
                            <p class="list__card-description body--sm">
                                CMS developer manages both structured & unstructured content like software, strategies,
                                and security to utilize it in a precise manner. If you need to create CMS-based
                                websites, we can link you with reputable and advanced CMS Developers.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
                <div class="services-box">
                    <div class="list__card">
                        <div class="list__card-image-container">
                            <div class="list__card-image"><img src="/website/assets/images/Group1361.svg"></div>
                        </div>
                        <div class="list__card-content">
                            <h3 class="h5 list__card-title">
                                CMS Developer
                            </h3>
                            <p class="list__card-description body--sm">
                                CMS developer manages both structured & unstructured content like software, strategies,
                                and security to utilize it in a precise manner. If you need to create CMS-based
                                websites, we can link you with reputable and advanced CMS Developers.
                            </p>
                        </div> 
                        <!-- <a tabindex="0" href="" class="list__card-link minor-button-right">Read more
                            <i aria-hidden="true" class="fa fa-long-arrow-right"></i></a> -->
                    </div>
                </div>
            </div>
            <div class="list__services-company row no-gutters">
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 1</h2>
                        <p>Provide a streamlined application reviewing procedure that makes it easy to shortlist the
                            candidates.</p>
                    </div>
                </div>
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 2</h2>
                        <p>Provide direct linking with the candidate’s detail </p>
                    </div>
                </div>
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 3</h2>
                        <p> Confer support with arranging interviews and ensuring follow-up.</p>
                    </div>
                </div>
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 4</h2>
                        <p>Offer a platform where the you can perform end-to-end communication with the applicants.</p>
                    </div>
                </div>
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 5</h2>
                        <p>Offer scout connections options to keep in touch with the employees. </p>
                    </div>
                </div>
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 6</h2>
                        <p>Give expert advice on your job description and the salary you should offer.</p>
                    </div>
                </div>
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 7</h2>
                        <p>Through our packages, we provide a wide range of safety and screening tests.</p>
                    </div>
                </div>
                <div class="services-company-box col-12 col-md-6">
                    <div class="card-service-img">
                        <img class="mp-icon" src="/website/assets/images/megaphone.svg" alt="">
                    </div>
                    <div class="content-service">
                        <h2>Service No. 8</h2>
                        <p>Provide Proper Guidance on offer negotiation and counteroffer scenarios to save your time & money</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>
<script>
    import WebsiteNavbar from '../website/partials/navbar.vue';
    export default {
        data() {
            return {}
        },
        mounted() {},
        created() {},
        components: {
            WebsiteNavbar,
        },
        methods: {},
    };

</script>
