<template>
    <div>
        <WebsiteNavbar />
        <CompanyNavbar />
        <h1 class="pricing-plan-title about">About Us</h1>
        <section class="about-us-container container">
            <div class="bizlanca-about-wrap">
                <img src="/website/assets/images/about-us.png" alt="img">
                <div class="about-info">
                    <h1>What Is BizBlanca?</h1>
                    <p>While other recruiting platforms supports every department, BizBlanca solely focuses on the IT
                        Sector. It is one of the very few websites in Pakistan that connects job seekers with reputable
                        software houses and offers IT career opportunities. Bizblanca encourages and supports persons
                        who want to work in the field of Information Technology.</p>
                    <!-- <a href="" class="read-more-ank">READ MORE &nbsp; <i class="fas fa-arrow-right"></i></a> -->
                </div>
            </div>
            <div class="about-comp-info">
                <h2>How We Support Companies</h2>
                <p>BizBlanca has established specialist recruitment, sourcing knowledgeable, and skilled professionals
                    for jobs across Pakistan. We are not only backing the job seekers but also serving as a platform to
                    support the companies who want to hire expert employees. Whether you want to hire a developer, IT
                    consultant, software engineer, or Digital Marketer, etc. BizBlanca has got you covered throughout.
                </p>
            </div>
            <ul class="about-conuters">
                <li class="about-conuter-list">
                    <h1>3000</h1>
                    <p>Jobs</p>
                </li>
                 <li class="about-conuter-list">
                    <h1>1400</h1>
                    <p>Applicants</p>
                </li>
                <li class="about-conuter-list">
                    <h1>500</h1>
                    <p>Recruiters</p>
                </li>
                <li class="about-conuter-list customer">
                    <h1>95%</h1>
                    <p>Customer Satisfaction</p>
                </li>
            </ul>
        </section>
        <div class="our-goals-wrap">
            <div class="bizlanca-about-wrap container">
                <div class="about-info">
                    <h1>Our Goal</h1>
                    <p>With the goal of becoming the leading IT-job searching platform in Pakistan, BizBlanca is always
                        here to serve you with the best possible services. We aim to provide IT resources to companies,
                        appealing salaries to IT experts, and thoroughly promote the IT sector in the region.</p>
                </div>
                <img src="/website/assets/images/our-goal.svg" alt="img">
            </div>
        </div>
        <div class="our-team-wrap container">
            <h1>Our Team</h1>
            <p>The BizBlanca team is unique from others. We work as a team, each knowing our tasks individually. Each of
                our workers is exceptional in their own right, but it is their combined efforts that make BizBlanca such
                a fulfilling and pleasing job search platform. </p>
            <div class="team-card-list">
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>MUJTABA TARIQ</h3>
                        <h4>Business Development Executive</h4>
                        <p>From Lahore City, Punjab Province. Completed M.Phil. From Lahore Garrison University</p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>HAMZA SAQIB</h3>
                        <h4>Vice Project Manager</h4>
                        <p>From Lahore City, Punjab Province. Graduated from University of Management & Technology</p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>ABDULLAH NASIR</h3>
                        <h4>UI/UX Designer</h4>
                        <p>From Lahore City, Punjab Province. Graduated from University of South Asia</p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>MUHAMMAD AHMAD</h3>
                        <h4>Sr. Full Stack Developer</h4>
                        <p>From Lahore City, Punjab Province. Graduated from Superior University</p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>ABDUL SAMMAD</h3>
                        <h4>Backend Developer</h4>
                        <p>From Lahore City, Punjab Province. Under Graduation at GCUF University </p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>HAMZA MALIK</h3>
                        <h4>Sr. Backend Developer</h4>
                        <p>From Lahore City, Punjab Province. Graduated from Virtual University</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import WebsiteNavbar from '../website/partials/navbar.vue';
    export default {
        data() {
            return {}
        },
        mounted() {},
        created() {},
        components: {
            WebsiteNavbar,
        },
        methods: {},
    };

</script>
