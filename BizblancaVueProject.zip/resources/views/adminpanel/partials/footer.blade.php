<div class="footer">
    <div class="pull-right">
        www.idenbrid.com
    </div>
    <div>
        <strong>Copyright</strong> Idenbrid Inc &copy; 2021
    </div>
</div>