<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>New User Apply</title>
</head>
<body>
    <p>Applied job: {{$candidate->full_name}}</p>
    <p>Please wait for company to approch you</p>
</body>
</html>