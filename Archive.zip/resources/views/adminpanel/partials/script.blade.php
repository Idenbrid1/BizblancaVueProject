<!-- Mainly scripts -->
<script src="{{asset('adminpanel')}}/js/jquery-2.1.1.js"></script>
<script src="{{asset('adminpanel')}}/js/bootstrap.min.js"></script>
<script src="{{asset('adminpanel')}}/js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="{{asset('adminpanel')}}/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<!-- Peity -->
<script src="{{asset('adminpanel')}}/js/plugins/peity/jquery.peity.min.js"></script>
<script src="{{asset('adminpanel')}}/js/demo/peity-demo.js"></script>
<!-- Custom and plugin javascript -->
<script src="{{asset('adminpanel')}}/js/inspinia.js"></script>
<script src="{{asset('adminpanel')}}/js/plugins/pace/pace.min.js"></script>
<!-- jQuery UI -->
<script src="{{asset('adminpanel')}}/js/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Toastr -->
<script src="{{ asset('adminpanel') }}/js/plugins/sweetalert/sweetalert.min.js"></script>
<script src="{{ asset('adminpanel') }}/js/plugins/toastr/toastr.min.js"></script>
