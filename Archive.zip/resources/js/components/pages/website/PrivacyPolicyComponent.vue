<template>
    <div>
        <WebsiteNavbar />
        <CompanyNavbar />
        <h1 class="pricing-plan-title">Privacy Policy</h1>
        <div class="pacakges-plan-container container">
            <section class="privacy-policy-container">
                <ul class="privacy-policy-queries">
                    <li>
                        <h1>General</h1>
                        <p>
                            www.BizBlanca.com is a job site operated by IDENBRID INC. this privacy policy will help you
                            understand that how and where do we use the personal information that you share on our
                            website.
                        </p>
                    </li>
                    <li>
                        <h1>What Information Do We Collect About You?</h1>
                        <p>
                            When you register with the Website, we collect personal information about you. We do so in
                            order to provide you with the recruiting services offered on the Website, as well as for
                            administrative considerations. Your name, email address, and phone number are among the
                            personal data we gather. If you're searching for employment, we'll also inquire about the
                            type of job you're looking for and where you'd want to work.
                            If you decide to upload or create a CV, cover letter, personal statement, or other similar
                            document or information we will keep that information for as long your account is active
                            with the Website. If you decide to make any purchase on or through the Website, we may ask
                            you for the details needed to process any payment that is required by the relevant
                            third-party course provider. IIf you choose to take any of the Website's tests, we will keep
                            track of your replies and the outcomes of such assessments.
                        </p>
                    </li>
                    <li>
                        <h1>What Do We Do With Your Personal Data?</h1>
                        <p>
                            By registering with the Website it is believed that work searchers are actively pursuing
                            contact from prospective employers and recruiters about opportunities that fit the work
                            seekers’ sectors of interest. If you are looking for employment, we will make your personal
                            information available to recruiters and companies that use the Website to discover qualified
                            candidates for specific positions. We will also share your data within our main company
                            IDENBRID INC. and any present or future sister companies, to facilitate your work search.
                            Although the primary purpose of the Website is to allow work seekers, prospective employers,
                            and recruiters to find each other, work seekers have control of the extent to which your
                            data is shared with other recruiters and prospective employers through the contact
                            preferences section of the “MyPage” section on the Website. For job seekers, we will use
                            your personal provide you with the recruitment services that we provide, to manage your
                            account, and to email you about recruitment services which, for job seekers, includes job
                            alerts, and emails we feel are relevant to your field of interest.
                        </p>
                    </li>
                    <li>
                        <h1>Information on this Site</h1>
                        <p>
                            While we make every effort to guarantee the accuracy and completeness of the information on
                            our Website, some of it is provided to us by third parties, and we are unable to verify its
                            correctness or completeness. We disclaim any and all liability arising from any error or
                            omission in any of the information on our Website, as well as any liability originating from
                            information on the Website provided by you, another website user, or any other person.
                        </p>
                    </li>
                    <li>
                        <h1>Marketing</h1>
                        <p>
                            If you register as a job seeker on the Website, we will only send you information about our
                            recruiting services unless you are expressly opt-in to receive marketing material about
                            other products and services using your account's contact choices. You have the right to
                            withdraw your agreement to receive marketing materials based on your contact settings at any
                            time. You may also change your account's contact choices to prevent us from contacting you
                            about the recruiting services or courses accessible through the Website for which you
                            registered when you created your account.
                        </p>
                    </li>
                    <li>
                        <h1>Data Sharing and Transfers</h1>
                        <p>
                            Save where it is necessary to do so in order to you with the Website’s recruitment services
                            or to put you in touch with a third party as set out in this policy. Our servers save your
                            information. If we share your data with a third-party service provider in the course of
                            providing you with our services, such third parties must treat your data in line with
                            contracts that follow data protection regulations.
                        </p>
                    </li>
                    <li>
                        <h1>Access to your information and correction</h1>
                        <p>
                            We want to make sure that your information is correct and up-to-date, therefore any
                            information that we believe is erroneous will be deleted or amended. Should you wish to
                            deactivate your account please do so in your MyPage account settings. Amendments to your
                            account can be made on your MyPage. We want to make sure you have access to essential
                            work-related services throughout your career. However, you have the right to deactivate your
                            account at any time unless we are in the process of responding to any complaint that you
                            make. Please note that deactivating your account does not delete your account or details
                            from our server.
                        </p>
                    </li>
                    <li>
                        <h1>Cookies</h1>
                        <p>
                            Cookies are text files that are downloaded to your computer and used to gather basic
                            internet logs and visitor activity data. This information is used to track how visitors use
                            the Website, to produce statistical statistics on website activity, and to assist us in
                            making appropriate suggestions to you. When you use the Website, we also employ third-party
                            advertising businesses to show adverts. These businesses may use information about your
                            visits to this and other websites to target you with advertising for goods and services that
                            you may be interested in.
                        </p>
                    </li>
                    <li>
                        <h1>Security and Passwords</h1>
                        <p>
                            To register with the Website and to sign in when you visit the Website, you will need to use
                            a username and password. You are solely responsible for the security and proper use of your
                            password. Do not share your password with any other person. If you feel that your password
                            has been changed or hacked by someone else, you must inform us instantly.
                        </p>
                    </li>
                    <li>
                        <h1>Other Websites</h1>
                        <p>
                            Our Website contains links to 3rd-party and other websites as well. This privacy policy only
                            applies to this Website. We are not responsible for data security on other linked websites.
                        </p>
                    </li>
                    <li>
                        <h1>Changes to our Privacy Policy</h1>
                        <p>
                            We keep our privacy policy under regular review and we place every update on this web page.
                            This policy was last updated on 1st December 2021.
                        </p>
                    </li>
                    <li>
                        <h1>How to Contact Us</h1>
                        <p>
                            Got any queries regarding this privacy policy or about the information we hold? Please
                            contact us. Relevant contact details are provided on the Website.
                        </p>
                    </li>
                    <li>
                        <h1>How Do You Unsubscribe From Future Mailings?</h1>
                        <p>
                            If you have a BizBlanca jobseeker account, you can stop receiving emails by updating your
                            preferences in your MyPage account settings.
                        </p>
                    </li>
                </ul>
            </section>
        </div>
    </div>
</template>
<script>
    import WebsiteNavbar from '../website/partials/navbar.vue';
    export default {
        data() {
            return {

            }
        },
        mounted() {},
        created() {},
        components: {
            WebsiteNavbar,
        },
        methods: {

        },
    };

</script>
