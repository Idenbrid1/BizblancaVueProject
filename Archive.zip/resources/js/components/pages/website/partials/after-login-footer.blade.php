 <footer class="footer">
    <div class="container">
       <div class="footer__main row">
          <div class="nav col-lg-7 col-12">
             <div class="nav__col">
                <span class="nav__col-title" >For Employers</span>
                <a  class="nav__item"  href="#" target="_blank"  >Authorise Timesheets</a>
                <a class="nav__item"  href="#">Permanent Recruitment</a>
                <a class="nav__item"  href="#">Temporary Recruitment</a>
                <a class="nav__item"  href="#">Executive Search</a>
                <a class="nav__item"  href="#">All Services</a>
             </div>
             <div class="nav__col">
                <span class="nav__col-title" >For Candidates</span>
                <a class="nav__item" href="#" target="_blank">Submit Timesheets</a>
                <a class="nav__item"  href="#">Find a Role</a>
                <a class="nav__item"  href="#">Work with a Consultant</a>
                <a class="nav__item"  href="#">Learning &amp; Development</a>
             </div>
             <div class="nav__col">
                <span class="nav__col-title" >Our Expertise</span>
                <a class="nav__item"  href="#">Accountancy &amp; Finance</a>
                <a class="nav__item" href="#">Business Support</a>
                <a class="nav__item" href="#">Education</a>
                <a class="nav__item"  href="#">Technology</a>
                <a class="nav__item"  href="#">All Sectors</a>
             </div>
             <div class="nav__col">
                <span class="nav__col-title" >Our Expertise</span>
                <a class="nav__item"  href="#">Accountancy &amp; Finance</a>
                <a class="nav__item" href="#">Business Support</a>
                <a class="nav__item" href="#">Education</a>
                <a class="nav__item"  href="#">Technology</a>
                <a class="nav__item"  href="#">All Sectors</a>
             </div>
          </div>
       </div>
       <div class="row">
          <div role="navigation" aria-label="secondary-nav" class="footer__links col-12">
             <a class="nav__item" tabindex="0" href="/privacy-policy"> Privacy Policy</a><a class="nav__item" tabindex="0" href="/terms-and-conditions">Terms &amp; Conditions</a><a class="nav__item" tabindex="0" href="/cookies">Cookies</a><a class="nav__item" tabindex="0" href="/corporate-governance">Corporate Governance</a><a class="nav__item" tabindex="0" href="/slavery-statement">Slavery Statement</a><a target="_blank" rel="noreferrer noopener" href="https://esuite.reed.co.uk/" class="nav__item" tabindex="0">eBilling</a><a class="nav__item" tabindex="0" href="/sitemap">Sitemap</a>
          </div>
       </div>
    </div>
    <div class="container py-3 text-center">
       <a style="color: #fff;" href="www.idenbrid.com">
       © IDENBRID INC.™, 2021. All rights reserved.
       </a>
    </div>
 </footer>
