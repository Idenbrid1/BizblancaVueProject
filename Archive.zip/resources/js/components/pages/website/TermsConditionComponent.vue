<template>
    <div>
        <WebsiteNavbar />
        <CompanyNavbar />
        <h1 class="pricing-plan-title">Terms & Conditions</h1>
        <div class="pacakges-plan-container container">
            <section class="terms-condition-container">
                <ul class="terms-condition-queries">
                    <li>
                        <h1>General</h1>
                        <p>
                            Each time you access the BizBlanca site or mobile application, you are deemed to accept the
                            terms & conditions interpret them well, and utilize the application accordingly. Any
                            violation or breaching of our terms & conditions might lead you to face legal concerns.
                        </p>
                    </li>
                    <li>
                        <h1>Your Use of This Site</h1>
                        <p>
                            You may only use the Website for lawful purposes while seeking employment, purchasing
                            training courses, recruiting staff, or advertising your brand. You must not seek to
                            undermine the security and information of the Website in any situation. You must not attempt
                            to access, change, or delete any unlawful information in particular. Any information you
                            provide to the Website is strictly your responsibility. You are responsible for ensuring
                            that all information supplied by you is true, accurate, up-to-date, and not misleading,
                            deceiving, illegal, offensive, or spam. All the information, data, and files you put into
                            our site must be error-free and protected from any threats or viruses that might damage our
                            system or site. We retain the right, at our absolute discretion, to delete any information
                            provided by you from the Website at any time and for any reason without explaining.
                        </p>
                    </li>
                    <li>
                        <h1>Information Submitted By You.</h1>
                        <p>
                            We will use the information you provide to assist with the recruiting process and related
                            administrative duties, as well as to make purchasing training courses through this website.
                            We will process any data which you provide in completing the online registration or
                            application forms, assessments, or personal details which you complete or provide to us
                            utilizing the site in conformity with relevant data protection legislation. we go over more
                            about your data in our Privacy Policy. Please note that all Third Party recruitment agencies
                            have agreed to our Terms and Conditions and if they are found suspicious in breaching of the
                            Terms and Conditions, they will be prevented from using our services. Transfer outside
                            Pakistan: Personal information comprising of your CV may be accessed through the
                            BizBlanca.com database by third parties outside Pakistan. This could happen, for instance,
                            if you apply for a vacancy where the employer is based outside of the country.
                        </p>
                    </li>
                    <li>
                        <h1>Content Rights</h1>
                        <p>
                            International copyright, software, and trademark laws protect the rights in material on the
                            Website, and you need to use the Website in a way that does not infringe on these rights.
                            You are allowed to use and copy the website material for your purposes only, not for any
                            commercial or business objective.
                        </p>
                    </li>
                    <li>
                        <h1>Security & Passwords</h1>
                        <p>
                            To register or sign in to the Website, you will need to use a username and password. It is
                            only you who is going to be answerable for the proper and legal use of your password. And
                            you must not disclose your secret information to any other person. If you ever feel that
                            your password has been leaked or accessed by someone else, you must notify us as quickly as
                            possible. Afterward, We accept no liability for any unauthorized or improper use or
                            disclosure of any password.
                        </p>
                    </li>
                    <li>
                        <h1>Termination</h1>
                        <p>
                            We may terminate your registration and/or deny access to the Website or any part of it
                            (including any services, goods, or information available on or through the Website) at any
                            time with no need to give or explain to you a reason for doing so.
                        </p>
                    </li>
                    <li>
                        <h1>Liability</h1>
                        <p>
                            We accept no liability for any loss arising from your use of the Website and we hereby
                            exclude any such liability, whether in contract or otherwise. All claims, warranties, and
                            conditions about the Website are explicitly disclaimed. You undertake to hold us harmless
                            from any costs, expenses, claims, losses, liabilities, or procedures resulting from your use
                            or abuse of the Website. Ping us as quickly as possible if any person tries to make a false
                            claim or threatens you from using our website.
                        </p>
                    </li>
                    <li>
                        <h1>Choice of Law and Jurisdiction.</h1>
                        <p>
                            The use of the Website and any agreements entered into through the Website are to be
                            governed by and construed by Pakistani law. The courts of Pakistan are to have exclusive
                            jurisdiction to settle any dispute arising out of or in connection with the use of the
                            Website or any agreement made through the Website. Some of the goods or services offered
                            through the Website may not be lawful or may otherwise not be permitted in certain countries
                            outside Pakistan. If any illegal attempt made to order, receive, purchase, or otherwise
                            benefit from any such goods or services, we will not accept any liability for any losses
                            suffered by you in using the Website, which you would not have suffered had you been
                            accessing the Website as a Pakistan resident.
                        </p>
                    </li>
                </ul>
            </section>
        </div>
    </div>
</template>
<script>
    import WebsiteNavbar from '../website/partials/navbar.vue';
    export default {
        data() {
            return {

            }
        },
        mounted() {},
        created() {},
        components: {
            WebsiteNavbar,
        },
        methods: {

        },
    };

</script>
