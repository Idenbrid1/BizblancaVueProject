<template>
    <div>
        <WebsiteNavbar />
        <CompanyNavbar />
        <h1 class="pricing-plan-title about">About Us</h1>
        <section class="about-us-container container">
            <div class="bizlanca-about-wrap">
                <img src="/website/assets/images/about-us.png" alt="img">
                <div class="about-info">
                    <h1>Lorem ipsum dolor sit amet, consectetuer.</h1>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.</p>
                    <a href="" class="read-more-ank">READ MORE &nbsp; <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="about-comp-info">
                <h2>Lorem ipsum dolor sit amet, consectetuer.</h2>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                    ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum
                    dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor
                    sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem ipsum dolor sit
                    amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.</p>
            </div>
            <ul class="about-conuters">
                <li class="about-conuter-list">
                    <h1>10,000</h1>
                    <p>Jobs</p>
                </li>
                <li class="about-conuter-list">
                    <h1>27,000</h1>
                    <p>Recruiters</p>
                </li>
                <li class="about-conuter-list">
                    <h1>27,000</h1>
                    <p>Recruiters</p>
                </li>
                <li class="about-conuter-list customer">
                    <h1>95%</h1>
                    <p>Customer Satisfaction</p>
                </li>
            </ul>
        </section>
        <div class="our-goals-wrap">
            <div class="bizlanca-about-wrap container">
                <div class="about-info">
                    <h1>Our Goal</h1>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Lorem
                        ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.</p>
                </div>
                <img src="/website/assets/images/our-goal.svg" alt="img">
            </div>
        </div>
        <div class="our-team-wrap container">
            <h1>Our Team</h1>
            <div class="team-card-list">
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>MUJTABA TARIQ</h3>
                        <h4>Business Development Executive</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        </p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>HAMZA SAQIB</h3>
                        <h4>Vice Project Manager</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        </p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>ABDULLAH NASIR</h3>
                        <h4>UI/UX Designer</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        </p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>MUHAMMAD AHMAD</h3>
                        <h4>Sr. Full Stack Developer</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        </p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>ABDUL SAMMAD</h3>
                        <h4>Backend Developer</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        </p>
                    </div>
                </div>
                <div class="team-card-box">
                    <div class="image-person">
                        <img class="member-pic" src="/website/assets/images/team-member.png" alt="img">
                        <ul class="social__links-list">
                            <li><a href="" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-card-content">
                        <h3>HAMZA MALIK</h3>
                        <h4>Sr. Backend Developer</h4>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import WebsiteNavbar from '../website/partials/navbar.vue';
    export default {
        data() {
            return {}
        },
        mounted() {},
        created() {},
        components: {
            WebsiteNavbar,
        },
        methods: {},
    };

</script>
